window.addEventListener('keydown', function (e) {
          window.location=("game.html")
        }, false);



