//checks for key press and opens the game
window.addEventListener('keydown', function (e) {
          window.location=("game.html")
        }, false);



